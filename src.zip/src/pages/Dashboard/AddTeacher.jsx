import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { toast } from "react-hot-toast"
import { X } from "lucide-react"

export default function AddTeacher() {
  const navigate = useNavigate()
  const [formData, setFormData] = useState({
    fullName: "",
    class: "",
    email: "",
    gender: "",
    subject: "",
    age: "",
    about: "",
    image: null,
  })

  const handleSubmit = async (e) => {
    e.preventDefault()
    toast.success("Teacher added successfully!")
    navigate("/teachers")
  }

  const handleImageChange = (e) => {
    const file = e.target.files[0]
    if (file && file.type.startsWith("image/")) {
      setFormData((prev) => ({ ...prev, image: file }))
    } else {
      toast.error("Please select a valid image file")
    }
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-semibold">Add teacher</h1>
        <button onClick={handleSubmit} className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">
          Save
        </button>
      </div>

      <form onSubmit={handleSubmit} className="max-w-4xl grid grid-cols-2 gap-6">
        <div className="space-y-2">
          <label className="block text-sm font-medium">Full Name</label>
          <input
            type="text"
            required
            value={formData.fullName}
            onChange={(e) => setFormData((prev) => ({ ...prev, fullName: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Class</label>
          <select
            required
            value={formData.class}
            onChange={(e) => setFormData((prev) => ({ ...prev, class: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">Select class</option>
            <option value="JSS 1">JSS 1</option>
            <option value="JSS 2">JSS 2</option>
            <option value="JSS 3">JSS 3</option>
            <option value="JSS 4">JSS 4</option>
            <option value="JSS 5">JSS 5</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Email address</label>
          <input
            type="email"
            required
            value={formData.email}
            onChange={(e) => setFormData((prev) => ({ ...prev, email: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Gender</label>
          <select
            required
            value={formData.gender}
            onChange={(e) => setFormData((prev) => ({ ...prev, gender: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">Select gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Subject</label>
          <select
            required
            value={formData.subject}
            onChange={(e) => setFormData((prev) => ({ ...prev, subject: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          >
            <option value="">Select subject</option>
            <option value="Mathematics">Mathematics</option>
            <option value="English">English</option>
            <option value="Physics">Physics</option>
            <option value="Chemistry">Chemistry</option>
            <option value="Biology">Biology</option>
          </select>
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Age</label>
          <input
            type="number"
            required
            value={formData.age}
            onChange={(e) => setFormData((prev) => ({ ...prev, age: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>

        <div className="col-span-2 space-y-2">
          <label className="block text-sm font-medium">About</label>
          <textarea
            rows={4}
            value={formData.about}
            onChange={(e) => setFormData((prev) => ({ ...prev, about: e.target.value }))}
            className="w-full px-3 py-2 border rounded-md"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-sm font-medium">Import Img</label>
          <div className="relative">
            <input
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="w-full px-3 py-2 border rounded-md"
            />
            {formData.image && (
              <button
                type="button"
                onClick={() => setFormData((prev) => ({ ...prev, image: null }))}
                className="absolute right-2 top-1/2 -translate-y-1/2"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  )
}

