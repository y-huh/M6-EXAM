import React from 'react'

const Settingss = () => {
  return (
    <div>Settingss</div>
  )
}

export default Settingss