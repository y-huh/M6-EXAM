import React from 'react'

const TweetsReplies = () => {
  return (
    <div>TweetsReplies</div>
  )
}

export default TweetsReplies