import React from 'react'

const Tweets = () => {
  return (
    <div>Tweets</div>
  )
}

export default Tweets