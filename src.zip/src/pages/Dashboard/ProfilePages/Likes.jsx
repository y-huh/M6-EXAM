import React from 'react'

const Likes = () => {
  return (
    <div>Likes</div>
  )
}

export default Likes