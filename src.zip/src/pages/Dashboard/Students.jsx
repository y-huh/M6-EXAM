import React from 'react'

const Students = () => {
  return (
    <div>Students</div>
  )
}

export default Students