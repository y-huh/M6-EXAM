import Home from "./Home"
import AddTeacher from "./AddTeacher"
import Teachers from "./Teachers"
import Students from "./Students"
import Billing from "./Billing"
import  Settingss  from "./Settingss"


export {Home,Settingss,Billing,AddTeacher,Teachers,Students}