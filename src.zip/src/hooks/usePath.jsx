export const PATH = {
    home: "/",
    teachers: "/teachers",
    addTeacher: "/teachers/add", // This is important
    students: "/students",
    billing: "/billing",
    settingss: "/settingss",
    exam: "/exam",
    register: "/register",
    features: "/features",
  }
  
  